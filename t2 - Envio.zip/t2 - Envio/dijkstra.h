#ifndef DIJKSTRA_H_INCLUDED
#define DIJKSTRA_H_INCLUDED

void Dijkstra(int num, int mat[num][num], int origem, int distancia[], int predecessores[]);


#endif // DIJKSTRA_H_INCLUDED
